package com.example.HotelBillingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelBillingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelBillingSystemApplication.class, args);
	}

}
