package com.example.HotelBillingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelBillingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
